#!/usr/bin/env python3
"""
Estimate an effective controller affinity from Study-05 microscopic trajectories.

The binary coarse-graining is target Z versus non-target.  For controlled
microscopic exposures define

    p_plus  = P(non-target -> target | controlled)
    p_minus = P(target -> non-target | controlled)

A local-detailed-balance directional affinity is then estimated from

    F_eff = log(p_plus / p_minus).

This rate-ratio estimate only uses the forward/backward directional asymmetry.
The original discrete-time finite-bias kernel additionally imposes
p_plus + p_minus = 1.  The LLM trajectories need not satisfy that kinetic
constraint.  A useful diagnostic is therefore

    gamma_eff = p_plus + p_minus,

which becomes an overall "lazy" kinetic prefactor in the extension

    p_plus  = gamma * sigma(F)
    p_minus = gamma * sigma(-F).

The script also constructs a matched-NOOP diagnostic using the same microscopic
slot indices as the controlled positions in the paired ADVOCATE trajectory.
That NOOP quantity is NOT automatically h_e; separating h_c and h_e requires
additional mechanistic assumptions and preferably focal epistemic-state
conditioning.

Input can be either:
  * relational_population_study05_delivery.zip
  * the extracted delivery directory

Outputs:
  affinity_summary.csv
  affinity_by_task.csv
  affinity_by_x0.csv
  affinity_by_task_x0.csv
  matched_noop_diagnostic.csv
  episode_counts.csv
  affinity_summary.json
  effective_affinity.png
"""

from __future__ import annotations
import argparse
import csv
import json
import math
import random
import shutil
import tempfile
import zipfile
from collections import defaultdict
from pathlib import Path


def log_ratio(p_plus: float, p_minus: float) -> float:
    if p_plus <= 0 or p_minus <= 0:
        return float("inf")
    return math.log(p_plus / p_minus)


def jeffreys_prob(k: int, n: int) -> float:
    # Beta(1/2,1/2) posterior mean; used only to stabilize sparse bootstrap
    # replicates and zero reverse counts.
    return (k + 0.5) / (n + 1.0)


def summarize_counts(rows):
    n_plus = sum(r["n_plus"] for r in rows)
    k_plus = sum(r["k_plus"] for r in rows)
    n_minus = sum(r["n_minus"] for r in rows)
    k_minus = sum(r["k_minus"] for r in rows)

    p_plus = k_plus / n_plus if n_plus else float("nan")
    p_minus = k_minus / n_minus if n_minus else float("nan")
    F_raw = log_ratio(p_plus, p_minus)

    p_plus_j = jeffreys_prob(k_plus, n_plus)
    p_minus_j = jeffreys_prob(k_minus, n_minus)
    F_j = math.log(p_plus_j / p_minus_j)

    gamma_raw = p_plus + p_minus
    gamma_j = p_plus_j + p_minus_j

    return {
        "n_plus": n_plus,
        "k_plus": k_plus,
        "p_plus": p_plus,
        "n_minus": n_minus,
        "k_minus": k_minus,
        "p_minus": p_minus,
        "F_eff_raw": F_raw,
        "odds_ratio_raw": math.exp(F_raw) if math.isfinite(F_raw) else float("inf"),
        "gamma_eff_raw": gamma_raw,
        "p_plus_jeffreys": p_plus_j,
        "p_minus_jeffreys": p_minus_j,
        "F_eff_jeffreys": F_j,
        "odds_ratio_jeffreys": math.exp(F_j),
        "gamma_eff_jeffreys": gamma_j,
        "kernel_complementarity_gap": 1.0 - gamma_raw,
    }


def quantile(xs, q):
    xs = sorted(xs)
    if not xs:
        return float("nan")
    pos = (len(xs) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return xs[lo]
    w = pos - lo
    return xs[lo] * (1 - w) + xs[hi] * w


def bootstrap(rows, strata_keys, n_boot=10000, seed=20260821):
    """
    Episode-cluster bootstrap.  Sampling is stratified by the requested design
    keys so the original matched experimental allocation is preserved.

    Sparse reverse transitions can produce p_minus=0 in bootstrap replicates.
    We therefore use the Jeffreys-stabilized probabilities for interval
    construction while retaining the raw estimate as the reported point
    estimate.
    """
    rng = random.Random(seed)
    strata = defaultdict(list)
    for r in rows:
        key = tuple(r[k] for k in strata_keys)
        strata[key].append(r)

    samples = {"p_plus": [], "p_minus": [], "F_eff": [], "gamma_eff": []}
    for _ in range(n_boot):
        draw = []
        for group in strata.values():
            for __ in range(len(group)):
                draw.append(group[rng.randrange(len(group))])
        s = summarize_counts(draw)
        samples["p_plus"].append(s["p_plus_jeffreys"])
        samples["p_minus"].append(s["p_minus_jeffreys"])
        samples["F_eff"].append(s["F_eff_jeffreys"])
        samples["gamma_eff"].append(s["gamma_eff_jeffreys"])

    out = {}
    for name, vals in samples.items():
        out[f"{name}_ci_low"] = quantile(vals, 0.025)
        out[f"{name}_boot_median"] = quantile(vals, 0.5)
        out[f"{name}_ci_high"] = quantile(vals, 0.975)
    return out


def discover_root(input_path: Path):
    tmp = None
    if input_path.is_file() and input_path.suffix.lower() == ".zip":
        tmp = tempfile.TemporaryDirectory(prefix="study05_affinity_")
        with zipfile.ZipFile(input_path) as zf:
            zf.extractall(tmp.name)
        root = Path(tmp.name)
    else:
        root = input_path
    return root, tmp


def parse_episode(micro_path: Path):
    round_path = micro_path.with_name("round_trajectory.jsonl")
    if not round_path.exists():
        return None
    with round_path.open() as f:
        round_row = json.loads(next(f))

    target = round_row["controller_target"]
    task = round_row.get("task_id", "unknown_task")
    x0 = float(round_row["controller_target_share_before"])
    episode = round_row["episode_id"]
    action = round_row["controller_action"]

    events = []
    with micro_path.open() as f:
        for line in f:
            d = json.loads(line)
            before_t = d["focal_opinion_before"] == target
            after_t = d["focal_opinion_after"] == target
            events.append({
                "task": task,
                "x0": x0,
                "episode": episode,
                "slot": int(d["within_round_index"]),
                "action": action,
                "controlled_slot": bool(d["controlled_slot"]),
                "before_target": before_t,
                "after_target": after_t,
            })
    return round_row, events


def counts_for_events(events):
    n_plus = k_plus = n_minus = k_minus = 0
    for e in events:
        if e["before_target"]:
            n_minus += 1
            if not e["after_target"]:
                k_minus += 1
        else:
            n_plus += 1
            if e["after_target"]:
                k_plus += 1
    return n_plus, k_plus, n_minus, k_minus


def make_episode_rows(all_episodes):
    episode_rows = []
    for key, ep in all_episodes.items():
        task, x0, episode = key
        ctrl = [e for e in ep["events"]
                if e["action"] == "ADVOCATE_Z" and e["controlled_slot"]]
        if not ctrl:
            continue
        nplus, kplus, nminus, kminus = counts_for_events(ctrl)
        episode_rows.append({
            "task": task,
            "x0": x0,
            "episode": episode,
            "n_plus": nplus,
            "k_plus": kplus,
            "n_minus": nminus,
            "k_minus": kminus,
        })
    return episode_rows


def grouped_summaries(rows, group_keys, bootstrap_strata_remainder, n_boot, seed):
    groups = defaultdict(list)
    for r in rows:
        key = tuple(r[k] for k in group_keys)
        groups[key].append(r)

    output = []
    for i, (key, group) in enumerate(sorted(groups.items(), key=lambda kv: kv[0])):
        s = summarize_counts(group)
        strata = bootstrap_strata_remainder(group_keys, group)
        b = bootstrap(group, strata, n_boot=n_boot, seed=seed + i)
        row = {}
        for k, v in zip(group_keys, key):
            row[k] = v
        row.update(s)
        row.update(b)
        output.append(row)
    return output


def write_csv(path, rows):
    if not rows:
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path, help="Study-05 delivery ZIP or extracted directory")
    ap.add_argument("--out", type=Path, default=Path("effective_affinity_results"))
    ap.add_argument("--bootstrap", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=20260821)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    root, tmp = discover_root(args.input)

    all_episodes = {}
    for micro in root.rglob("micro_slot_trajectory.jsonl"):
        parsed = parse_episode(micro)
        if parsed is None:
            continue
        round_row, events = parsed
        key = (round_row.get("task_id", "unknown_task"),
               float(round_row["controller_target_share_before"]),
               round_row["episode_id"])
        all_episodes[key] = {"round": round_row, "events": events}

    if not all_episodes:
        raise SystemExit("No micro_slot_trajectory.jsonl files found.")

    episode_rows = make_episode_rows(all_episodes)
    if not episode_rows:
        raise SystemExit("No controlled ADVOCATE_Z microscopic slots found.")

    # Main pooled result: preserve the 2-task x 3-state experimental allocation.
    pooled = summarize_counts(episode_rows)
    pooled.update(bootstrap(
        episode_rows, ["task", "x0"],
        n_boot=args.bootstrap, seed=args.seed
    ))
    pooled_row = {"scope": "all_controlled_ADV_slots", **pooled}
    write_csv(args.out / "affinity_summary.csv", [pooled_row])

    # By task, preserving x0 allocation inside each task.
    by_task = []
    for task in sorted({r["task"] for r in episode_rows}):
        g = [r for r in episode_rows if r["task"] == task]
        s = summarize_counts(g)
        s.update(bootstrap(g, ["x0"], args.bootstrap, args.seed + 10))
        by_task.append({"task": task, **s})
    write_csv(args.out / "affinity_by_task.csv", by_task)

    # By x0, preserving task allocation inside each state.
    by_x0 = []
    for x0 in sorted({r["x0"] for r in episode_rows}):
        g = [r for r in episode_rows if r["x0"] == x0]
        s = summarize_counts(g)
        s.update(bootstrap(g, ["task"], args.bootstrap, args.seed + 20))
        by_x0.append({"x0": x0, **s})
    write_csv(args.out / "affinity_by_x0.csv", by_x0)

    # Individual task x state cells.
    by_cell = []
    cells = sorted({(r["task"], r["x0"]) for r in episode_rows})
    for j, (task, x0) in enumerate(cells):
        g = [r for r in episode_rows if r["task"] == task and r["x0"] == x0]
        s = summarize_counts(g)
        # one design cell => episode-cluster bootstrap with a single stratum
        for r in g:
            r["_one"] = 0
        s.update(bootstrap(g, ["_one"], args.bootstrap, args.seed + 30 + j))
        by_cell.append({"task": task, "x0": x0, **s})
    write_csv(args.out / "affinity_by_task_x0.csv", by_cell)
    write_csv(args.out / "episode_counts.csv", episode_rows)

    # Matched-NOOP diagnostic.  Use the ADVOCATE controlled position pattern
    # from the paired state/replicate as a mask on the NOOP arm.
    # The delivery uses cell pairs and common replicate suffixes.
    controlled_positions = {}
    for key, ep in all_episodes.items():
        task, x0, episode = key
        if ep["round"]["controller_action"] != "ADVOCATE_Z":
            continue
        rep = episode.rsplit("-", 1)[-1]
        pos = {e["slot"] for e in ep["events"] if e["controlled_slot"]}
        controlled_positions[(task, x0, rep)] = pos

    noop_episode_rows = []
    for key, ep in all_episodes.items():
        task, x0, episode = key
        if ep["round"]["controller_action"] != "NO_OP":
            continue
        rep = episode.rsplit("-", 1)[-1]
        pos = controlled_positions.get((task, x0, rep))
        if pos is None:
            continue
        ev = [e for e in ep["events"] if e["slot"] in pos]
        nplus, kplus, nminus, kminus = counts_for_events(ev)
        noop_episode_rows.append({
            "task": task, "x0": x0, "episode": episode,
            "n_plus": nplus, "k_plus": kplus,
            "n_minus": nminus, "k_minus": kminus,
        })

    if noop_episode_rows:
        noop = summarize_counts(noop_episode_rows)
        noop.update(bootstrap(
            noop_episode_rows, ["task", "x0"],
            n_boot=args.bootstrap, seed=args.seed + 100
        ))
        write_csv(args.out / "matched_noop_diagnostic.csv",
                  [{"scope": "matched_NOOP_slots", **noop}])

    summary_json = {
        "main": pooled_row,
        "by_task": by_task,
        "by_x0": by_x0,
        "by_task_x0": by_cell,
        "notes": {
            "affinity_definition": "F_eff = ln[p_plus / p_minus]",
            "p_plus": "P(non-target -> target | controlled slot)",
            "p_minus": "P(target -> non-target | controlled slot)",
            "gamma_eff": "p_plus + p_minus; kinetic/activity prefactor in a lazy LDB kernel",
            "bootstrap": "episode-cluster, stratified; Jeffreys stabilization for sparse reverse events",
            "important_limitation": (
                "The delivered microscopic JSONL records do not contain focal-agent identity "
                "or focal epistemic stratum, so h_c and h_e cannot be cleanly separated from "
                "these logs alone."
            ),
        },
    }
    with (args.out / "affinity_summary.json").open("w") as f:
        json.dump(summary_json, f, indent=2, allow_nan=True)

    # Optional plot (matplotlib is not required for the numerical analysis).
    try:
        import matplotlib.pyplot as plt

        labels = ["pooled"] + [r["task"] for r in by_task]
        vals = [pooled["F_eff_raw"]] + [r["F_eff_raw"] for r in by_task]
        lows = [pooled["F_eff_ci_low"]] + [r["F_eff_ci_low"] for r in by_task]
        highs = [pooled["F_eff_ci_high"]] + [r["F_eff_ci_high"] for r in by_task]

        fig, ax = plt.subplots(figsize=(6.5, 4.0))
        xs = range(len(labels))
        yerr = [[v-l for v,l in zip(vals,lows)],
                [h-v for v,h in zip(vals,highs)]]
        ax.errorbar(xs, vals, yerr=yerr, fmt="o", capsize=4)
        ax.axhline(0, linewidth=1)
        ax.set_xticks(list(xs), labels)
        ax.set_ylabel(r"effective directional affinity $F_{\rm eff}$")
        ax.set_title("Controlled microscopic transition-rate ratio")
        fig.tight_layout()
        fig.savefig(args.out / "effective_affinity.png", dpi=180)
        plt.close(fig)
    except Exception as exc:
        (args.out / "plot_warning.txt").write_text(str(exc))

    print(json.dumps(pooled_row, indent=2, allow_nan=True))

    if tmp is not None:
        tmp.cleanup()


if __name__ == "__main__":
    main()
