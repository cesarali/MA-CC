# Effective affinity from Study-05 microscopic trajectories

## Main estimate

Using only **controlled microscopic slots** in the forced-ADVOCATE arms, and
coarse-graining each focal vote to target \(Z\) versus non-target:

- eligible non-target controlled exposures: **572**
- non-target -> target transitions: **208**
- \(p_+ = P(0\to Z\mid\mathrm{controlled}) = 0.3636\)
- eligible target controlled exposures: **508**
- target -> non-target transitions: **4**
- \(p_- = P(Z\to 0\mid\mathrm{controlled}) = 0.0079\)

The directional transition-rate ratio gives

\[
F_{\rm eff} = \ln\frac{p_+}{p_-}
= 3.833,
\]

or a toward-target / away-from-target rate ratio of approximately

\[
e^{F_{\rm eff}} = 46.2:1.
\]

A stratified episode-cluster bootstrap (10,000 resamples; Jeffreys stabilization
inside sparse resamples) gives an approximate 95% interval

\[
F_{\rm eff} \in
[3.06,\,4.88].
\]

## Important kinetic diagnostic

The original discrete-time finite-bias kernel additionally predicts
\(p_+ + p_- = 1\).  Empirically,

\[
p_+ + p_- = 0.372,
\]

far below one.  Therefore the **directional affinity is identifiable from the
forward/backward rate ratio, but the unit-attempt discrete-time kernel does not
describe the LLM transition activity**.

A minimal local-detailed-balance-compatible interpretation is a lazy kinetic
prefactor \(\gamma\),

\[
p_+ = \gamma\sigma(F),\qquad
p_- = \gamma\sigma(-F),
\]

for which the same data give

\[
\gamma_{\rm eff} = 0.372.
\]

This separates **directional bias** \(F\) from **kinetic compliance/activity**
\(\gamma\).

## What cannot yet be identified

The current delivery is sufficient for the net directional affinity
\(F_{\rm eff}\), but not for a clean decomposition
\(F=h_c-h_e\).  The microscopic JSONL records contain pre/post focal votes and
controlled-slot status, but not the focal-agent identity or focal epistemic
stratum.  The theory itself requires conditioning on epistemic/social context
before interpreting the split into controller affinity \(h_c\) and opposing
load \(h_e\).

The script also reports a matched-NOOP directional diagnostic, but it is
deliberately **not** labeled as \(h_e\).

## Reproduce

```bash
python scripts/estimate_effective_affinity.py \
    relational_population_study05_delivery.zip \
    --out effective_affinity_results \
    --bootstrap 10000
```
