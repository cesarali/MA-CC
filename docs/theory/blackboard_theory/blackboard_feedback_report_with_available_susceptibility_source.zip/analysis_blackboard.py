import math
from math import comb
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

OUT = Path('/mnt/data/blackboard_report_ext')
FIG = OUT/'figures'
DATA = OUT/'data'
FIG.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

# Baseline used in the supplied technical note, augmented by the sensing-policy
# parameters of the original single-affinity report.
N = 24
M = 24
B = 18
q = 3
q_c = 12
beta = 4.0
theta = 0.5
gamma0 = 0.35
p0 = 0.70
gamma1 = 0.65
p1 = 0.90


def logistic(z):
    if z >= 0:
        return 1.0/(1.0+math.exp(-z))
    ez = math.exp(z)
    return ez/(1.0+ez)


def logit(p):
    return math.log(p/(1.0-p))


def exposure_probability(B, b, q):
    if b <= 0 or q <= 0:
        return 0.0
    m = min(q, B+b)
    no_controller = comb(B, m)/comb(B+b, m) if m <= B else 0.0
    return 1.0-no_controller


def K_kernel(N, gamma, p):
    K = np.zeros((N+1, N+1), dtype=float)
    for n in range(N+1):
        x = n/N
        up = gamma*(1.0-x)*p
        down = gamma*x*(1.0-p)
        K[n,n] = 1.0-up-down
        if n < N:
            K[n,n+1] = up
        if n > 0:
            K[n,n-1] = down
    return K


def effective_params(B,b,q,gamma0,p0,gamma1,p1):
    w = exposure_probability(B,b,q)
    gb = (1.0-w)*gamma0 + w*gamma1
    if gb <= 0:
        pb = 0.5
    else:
        pb = ((1.0-w)*gamma0*p0 + w*gamma1*p1)/gb
    return w, gb, pb


def round_kernels(N,M,B,b,q,gamma0,p0,gamma1,p1):
    w, gb, pb = effective_params(B,b,q,gamma0,p0,gamma1,p1)
    K0 = K_kernel(N,gamma0,p0)
    Kb = K_kernel(N,gb,pb)
    Q0 = np.linalg.matrix_power(K0,M)
    Q1 = np.linalg.matrix_power(Kb,M)
    return w, gb, pb, K0, Kb, Q0, Q1


def F_M(x,N,M,gamma,p):
    r = (1.0-gamma/N)**M
    return p + (x-p)*r


def chi_formula(x,N,M,gamma0,p0,gammab,pb):
    return F_M(x,N,M,gammab,pb) - F_M(x,N,M,gamma0,p0)


def sensor_kernel(N,qc):
    S = np.zeros((N+1,qc+1), dtype=float)
    den = comb(N,qc)
    for n in range(N+1):
        lo=max(0,qc-(N-n)); hi=min(qc,n)
        for y in range(lo,hi+1):
            S[n,y] = comb(n,y)*comb(N-n,qc-y)/den
    return S


def policy_curves(N,qc,beta,theta):
    S = sensor_kernel(N,qc)
    pi1 = np.asarray([logistic(beta*(theta-y/qc)) for y in range(qc+1)])
    a = S@pi1
    return a,S,pi1


def rel_entropy_bits(p,q):
    mask=p>0
    if np.any(q[mask] <= 0):
        return math.inf
    return float(np.sum(p[mask]*np.log2(p[mask]/q[mask])))


def local_T(Q0,Q1,a):
    out=np.zeros(Q0.shape[0])
    for n in range(Q0.shape[0]):
        mix=(1-a[n])*Q0[n]+a[n]*Q1[n]
        out[n]=(1-a[n])*rel_entropy_bits(Q0[n],mix)+a[n]*rel_entropy_bits(Q1[n],mix)
    return out


def binary_entropy_bits(a):
    a=np.asarray(a,dtype=float)
    out=np.zeros_like(a)
    mask=(a>0)&(a<1)
    out[mask] = -a[mask]*np.log2(a[mask])-(1-a[mask])*np.log2(1-a[mask])
    return out


def info_metrics(Q0,Q1,a,chi):
    T=local_T(Q0,Q1,a)
    H=binary_entropy_bits(a)
    eta_if=np.full_like(T,np.nan)
    m=H>1e-15
    eta_if[m]=T[m]/H[m]
    bound=2.0*a*(1-a)*chi**2/math.log(2.0)
    eta_ir=np.full_like(T,np.nan)
    m=T>1e-15
    eta_ir[m]=bound[m]/T[m]
    return T,H,eta_if,bound,eta_ir


def binomial_ensemble(N,x):
    p=np.asarray([comb(N,n)*x**n*(1-x)**(N-n) for n in range(N+1)],dtype=float)
    return p/p.sum()


def system_entropy(p,N):
    total=0.0
    for n,pn in enumerate(p):
        if pn>0:
            total += -pn*math.log(pn)+pn*math.log(comb(N,n))
    return total


def sensing_information_nats(p,S):
    py=p@S
    total=0.0
    for n,pn in enumerate(p):
        if pn<=0: continue
        for y,sy in enumerate(S[n]):
            if sy>0:
                total += pn*sy*math.log(sy/py[y])
    return total,py


def path_thermo(B,b,q,qc,beta,theta,gamma0,p0,gamma1,p1,pinit_x=0.25):
    a,S,pi1=policy_curves(N,qc,beta,theta)
    w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,b,q,gamma0,p0,gamma1,p1)
    p=binomial_ensemble(N,pinit_x)
    Qpi=(1-a)[:,None]*Q0+a[:,None]*Q1
    pnext=p@Qpi
    Isens,py=sensing_information_nats(p,S)
    dS=system_entropy(pnext,N)-system_entropy(p,N)
    grid=np.arange(N+1,dtype=float)
    mu0=Q0@grid-grid
    mu1=Q1@grid-grid
    h0=logit(p0)
    hb=logit(pb)
    Jsil=float(np.sum(p*mu0))
    Jadv=float(np.sum(p*a*mu1))
    Jtot=float(np.sum(p*((1-a)*mu0+a*mu1)))
    Jex=float(np.sum(p*a*(mu1-mu0)))
    A=float(np.sum(p*((1-a)*h0*mu0+a*hb*mu1)))
    Aex=float(h0*Jex + (hb-h0)*Jadv)
    Sigma=dS+Isens+A
    eta_path=A/(A+Isens) if (A>=0 and A+Isens>1e-15) else math.nan
    return dict(w=w,gammab=gb,pb=pb,h0=h0,hb=hb,p=p,pnext=pnext,a=a,S=S,pi1=pi1,Q0=Q0,Q1=Q1,
                mu0=mu0,mu1=mu1,Isens=Isens,dS=dS,Jsil=Jsil,Jadv=Jadv,Jtot=Jtot,Jex=Jex,A=A,Aex=Aex,Sigma=Sigma,eta_path=eta_path)


def direct_path_kl(z):
    p=z['p']; pnext=z['pnext']; S=z['S']; pi1=z['pi1']; Q0=z['Q0']; Q1=z['Q1']; py=p@S
    total=0.0
    for n,pn in enumerate(p):
        if pn<=0: continue
        for y,sy in enumerate(S[n]):
            if sy<=0: continue
            for u,Q in ((0,Q0),(1,Q1)):
                pu=(1-pi1[y]) if u==0 else pi1[y]
                if pu<=0: continue
                for m,qnm in enumerate(Q[n]):
                    if qnm<=0: continue
                    f=pn*sy*pu*qnm
                    r=pnext[m]*py[y]*pu*Q[m,n]
                    if r<=0: return math.inf
                    total += f*math.log(f/r)
    return total


def savefig(name):
    plt.tight_layout()
    plt.savefig(FIG/name, dpi=180, bbox_inches='tight')
    plt.close()

# Figure 1: exposure curves
bs=np.arange(0,25)
plt.figure(figsize=(7.0,4.4))
for qv in [1,2,3,4,6]:
    plt.plot(bs,[exposure_probability(B,int(b),qv) for b in bs],label=fr'$q={qv}$')
plt.xlabel('Controller messages posted $b$')
plt.ylabel(r'Exposure probability $w_b$')
plt.title(rf'Blackboard exposure probability ($B={B}$ eligible peer messages)')
plt.ylim(-0.02,1.02); plt.legend()
savefig('fig01_exposure_vs_budget.pdf')

# Core x-b grids under baseline.
a,S,pi1=policy_curves(N,q_c,beta,theta)
xs=np.arange(N+1)/N
chi_grid=[]; T_grid=[]; eif_grid=[]; eir_grid=[]
rows=[]
for b in bs:
    w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,int(b),q,gamma0,p0,gamma1,p1)
    chi=np.asarray([chi_formula(x,N,M,gamma0,p0,gb,pb) for x in xs])
    T,H,eif,bnd,eir=info_metrics(Q0,Q1,a,chi)
    chi_grid.append(chi);T_grid.append(T);eif_grid.append(eif);eir_grid.append(eir)
    for n,x in enumerate(xs):
        rows.append([b,n,x,w,gb,pb,a[n],chi[n],T[n],H[n],eif[n],bnd[n],eir[n]])
chi_grid=np.asarray(chi_grid).T; T_grid=np.asarray(T_grid).T; eif_grid=np.asarray(eif_grid).T; eir_grid=np.asarray(eir_grid).T
# Availability-normalized susceptibility.  The fully saturated state x=1 is
# undefined and is kept as NaN.  This is a diagnostic normalization, not an
# efficiency: the full-round intervention-minus-silence response includes both
# new target adoption and differential retention, so chi_avail can exceed one.
chi_avail_grid=np.full_like(chi_grid,np.nan,dtype=float)
for ix,x in enumerate(xs):
    if x < 1.0:
        chi_avail_grid[ix,:]=chi_grid[ix,:]/(1.0-x)

# Rewrite the state-budget table with the availability-normalized column.
rows_ext=[]
for row in rows:
    b,n,x,w,gb,pb,an,chi,T,H,eif,bnd,eir=row
    chi_avail=chi/(1.0-x) if x < 1.0 else math.nan
    rows_ext.append([b,n,x,w,gb,pb,an,chi,chi_avail,T,H,eif,bnd,eir])
with open(DATA/'state_budget_grid.csv','w',newline='') as f:
    wr=csv.writer(f);wr.writerow(['b','n','x','w_b','gamma_b','p_b','a_n','chi','chi_available','T_pi_bits','H_U_given_n_bits','eta_IF','B_IR_bits','eta_IR']);wr.writerows(rows_ext)

# Figure 2: susceptibility curves
plt.figure(figsize=(7.0,4.6))
for b in [3,6,9,12,18,24]:
    idx=int(b)
    plt.plot(xs,chi_grid[:,idx],label=fr'$b={b}$')
plt.axhline(0,linewidth=0.8)
plt.xlabel('Initial target fraction $x$')
plt.ylabel(r'Blackboard susceptibility $\chi_b(x)$')
plt.title('Exact intervention-minus-silence susceptibility')
plt.legend(ncol=2)
savefig('fig02_susceptibility_curves.pdf')

# Figure 3: susceptibility heatmap
plt.figure(figsize=(7.2,4.8))
img=plt.imshow(chi_grid,origin='lower',aspect='auto',extent=[0,24,0,1])
plt.colorbar(img,label=r'$\chi_b(x)$')
plt.xlabel('Controller messages posted $b$');plt.ylabel('Initial target fraction $x=n/N$')
plt.title('Blackboard susceptibility phase diagram')
savefig('fig03_susceptibility_phase_x_b.pdf')

# Figure 3a: availability-normalized susceptibility heatmap.  Mask x=1.
plt.figure(figsize=(7.2,4.8))
masked=np.ma.masked_invalid(chi_avail_grid)
img=plt.imshow(masked,origin='lower',aspect='auto',extent=[0,24,0,1])
plt.colorbar(img,label=r'$\chi_{b,\mathrm{avail}}(x)=\chi_b(x)/(1-x)$')
plt.xlabel('Controller messages posted $b$');plt.ylabel('Initial target fraction $x=n/N$')
plt.title('Availability-normalized susceptibility phase diagram')
savefig('fig03a_susceptibility_available_phase_x_b.pdf')

# Figure 3b: state-local availability-normalized curves for representative budgets.
plt.figure(figsize=(7.0,4.6))
for b in [3,6,9,12,18,24]:
    plt.plot(xs[:-1],chi_avail_grid[:-1,int(b)],label=fr'$b={b}$')
plt.axhline(0,linewidth=0.8)
plt.xlabel('Initial target fraction $x$')
plt.ylabel(r'Availability-normalized susceptibility $\chi_{b,\mathrm{avail}}(x)$')
plt.title('Response per remaining non-target population mass')
plt.legend(ncol=2)
savefig('fig03b_susceptibility_available_curves.pdf')

# Figure 3c: compact budget summary at representative states and under the
# illustrative Binomial(N,0.25) occupancy.  The occupancy ratio weights each
# state by its available mass and excludes x=1.
pinit=binomial_ensemble(N,0.25)
plt.figure(figsize=(7.0,4.6))
for n,label in [(6,r'$x=0.25$'),(12,r'$x=0.50$'),(18,r'$x=0.75$')]:
    plt.plot(bs,chi_avail_grid[n,:],label=label)
occ_vals=[]
for ib,b in enumerate(bs):
    numerator=float(np.sum(pinit[:-1]*chi_grid[:-1,ib]))
    denominator=float(np.sum(pinit[:-1]*(1.0-xs[:-1])))
    occ_vals.append(numerator/denominator if denominator>0 else math.nan)
plt.plot(bs,occ_vals,linestyle='--',label=r'available-mass weighted, $p_{init}=\mathrm{Bin}(24,0.25)$')
plt.xlabel('Controller messages posted $b$')
plt.ylabel(r'$\chi_{b,\mathrm{avail}}$')
plt.title('Availability-normalized susceptibility versus message budget')
plt.legend()
savefig('fig03c_susceptibility_available_budget_summary.pdf')

# Numeric summary used by the report.
with open(DATA/'availability_susceptibility_summary.csv','w',newline='') as f:
    wr=csv.writer(f)
    wr.writerow(['b','chi_available_x025','chi_available_x050','chi_available_x075','available_mass_weighted_binom025','state_min_xlt1','state_max_xlt1'])
    for ib,b in enumerate(bs):
        vals=chi_avail_grid[:-1,ib]
        wr.writerow([int(b),chi_avail_grid[6,ib],chi_avail_grid[12,ib],chi_avail_grid[18,ib],occ_vals[ib],np.nanmin(vals),np.nanmax(vals)])

# Figure 4: T_pi heatmap
plt.figure(figsize=(7.2,4.8))
img=plt.imshow(T_grid,origin='lower',aspect='auto',extent=[0,24,0,1])
plt.colorbar(img,label=r'$T_\pi(n)$ [bits]')
plt.xlabel('Controller messages posted $b$');plt.ylabel('Initial target fraction $x=n/N$')
plt.title(r'State-local action-to-population information $T_\pi$')
savefig('fig04_Tpi_phase_x_b.pdf')

# Figure 5: eta_IF heatmap
plt.figure(figsize=(7.2,4.8))
img=plt.imshow(np.nan_to_num(eif_grid,nan=0.0),origin='lower',aspect='auto',extent=[0,24,0,1],vmin=0,vmax=1)
plt.colorbar(img,label=r'$\eta_{IF}=T_\pi/H(U\mid n)$')
plt.xlabel('Controller messages posted $b$');plt.ylabel('Initial target fraction $x=n/N$')
plt.title('Action-information fraction')
savefig('fig05_etaIF_phase_x_b.pdf')

# Figure 6: eta_IR heatmap
plt.figure(figsize=(7.2,4.8))
img=plt.imshow(np.nan_to_num(eir_grid,nan=0.0),origin='lower',aspect='auto',extent=[0,24,0,1],vmin=0,vmax=max(0.05,float(np.nanmax(eir_grid))))
plt.colorbar(img,label=r'$\eta_{IR}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel('Initial target fraction $x=n/N$')
plt.title('Information-response efficiency')
savefig('fig06_etaIR_phase_x_b.pdf')

# Figure 7: equal-compliance comparison; this is a structural check.
plt.figure(figsize=(7.0,4.6))
for b in [3,6,12,24]:
    w,gb,pb,*_=round_kernels(N,M,B,int(b),q,0.5,p0,0.5,p1)
    chi=np.asarray([chi_formula(x,N,M,0.5,p0,gb,pb) for x in xs])
    plt.plot(xs,chi,label=fr'$b={b}$')
plt.xlabel('Initial target fraction $x$');plt.ylabel(r'$\chi_b(x)$')
plt.title(r'Equal-compliance check: $\gamma_0=\gamma_1=0.5$')
plt.legend()
savefig('fig07_equal_compliance_chi.pdf')

# Parameter phase diagrams over exposed kernel p1, gamma1 at x=0.5, b=9.
p1s=np.linspace(0.50,0.98,70); g1s=np.linspace(0.10,1.0,70)
chi_pg=np.zeros((len(g1s),len(p1s))); T_pg=np.zeros_like(chi_pg); eir_pg=np.zeros_like(chi_pg)
nmid=N//2
for ig,g1v in enumerate(g1s):
    for ip,p1v in enumerate(p1s):
        w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,9,q,gamma0,p0,float(g1v),float(p1v))
        ch=np.asarray([chi_formula(x,N,M,gamma0,p0,gb,pb) for x in xs])
        T,H,eif,bnd,eir=info_metrics(Q0,Q1,a,ch)
        chi_pg[ig,ip]=ch[nmid];T_pg[ig,ip]=T[nmid];eir_pg[ig,ip]=eir[nmid] if np.isfinite(eir[nmid]) else 0

plt.figure(figsize=(7.2,4.8))
img=plt.imshow(chi_pg,origin='lower',aspect='auto',extent=[p1s[0],p1s[-1],g1s[0],g1s[-1]])
plt.colorbar(img,label=r'$\chi_b(x=0.5)$')
cs=plt.contour(p1s,g1s,chi_pg,levels=[0.0],linewidths=1.2)
plt.clabel(cs,fmt={0.0:'zero response'})
plt.xlabel(r'Exposed preference $p_1$');plt.ylabel(r'Exposed compliance $\gamma_1$')
plt.title(r'Response-sign phase diagram ($b=9,q=3,x=0.5$)')
savefig('fig08_chi_phase_p1_gamma1.pdf')

plt.figure(figsize=(7.2,4.8))
img=plt.imshow(T_pg,origin='lower',aspect='auto',extent=[p1s[0],p1s[-1],g1s[0],g1s[-1]])
plt.colorbar(img,label=r'$T_\pi(x=0.5)$ [bits]')
plt.xlabel(r'Exposed preference $p_1$');plt.ylabel(r'Exposed compliance $\gamma_1$')
plt.title(r'Action-information phase diagram ($b=9,q=3,x=0.5$)')
savefig('fig09_Tpi_phase_p1_gamma1.pdf')

plt.figure(figsize=(7.2,4.8))
img=plt.imshow(eir_pg,origin='lower',aspect='auto',extent=[p1s[0],p1s[-1],g1s[0],g1s[-1]],vmin=0,vmax=max(0.05,float(np.nanmax(eir_pg))))
plt.colorbar(img,label=r'$\eta_{IR}(x=0.5)$')
plt.xlabel(r'Exposed preference $p_1$');plt.ylabel(r'Exposed compliance $\gamma_1$')
plt.title(r'Information-response phase diagram ($b=9,q=3,x=0.5$)')
savefig('fig10_etaIR_phase_p1_gamma1.pdf')

# Figure 11: state-average Tpi under parameter sweeps, analogous to original compact summary.
plt.figure(figsize=(7.0,4.6))
for qv in [1,2,3,4,6]:
    vals=[]
    for b in bs:
        w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,int(b),qv,gamma0,p0,gamma1,p1)
        ch=np.asarray([chi_formula(x,N,M,gamma0,p0,gb,pb) for x in xs])
        T,*_=info_metrics(Q0,Q1,a,ch)
        vals.append(np.mean(T))
    plt.plot(bs,vals,label=fr'$q={qv}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel(r'Arithmetic state-average $\overline{T}_\pi$ [bits]')
plt.title('Effect of message-sample size on the action channel')
plt.legend()
savefig('fig11_Tpi_average_vary_q.pdf')

# Figure 12: varying q_c, keeping blackboard parameters fixed.
plt.figure(figsize=(7.0,4.6))
for qcv in [4,8,12,18,24]:
    av,_,_=policy_curves(N,qcv,beta,theta)
    vals=[]
    for b in bs:
        w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,int(b),q,gamma0,p0,gamma1,p1)
        ch=np.asarray([chi_formula(x,N,M,gamma0,p0,gb,pb) for x in xs])
        T,*_=info_metrics(Q0,Q1,av,ch)
        vals.append(np.mean(T))
    plt.plot(bs,vals,label=fr'$q_c={qcv}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel(r'Arithmetic state-average $\overline{T}_\pi$ [bits]')
plt.title('Effect of sensing resolution on the action channel')
plt.legend()
savefig('fig12_Tpi_average_vary_qc.pdf')

# Figure 13: controller-excess current vs budget for sensor sizes.
plt.figure(figsize=(7.0,4.6))
thermo_rows=[]
for qcv in [6,12,18]:
    vals=[]
    for b in bs:
        z=path_thermo(B,int(b),q,qcv,beta,theta,gamma0,p0,gamma1,p1,0.25)
        vals.append(z['Jex'])
        thermo_rows.append([qcv,b,z['w'],z['gammab'],z['pb'],z['h0'],z['hb'],z['Jsil'],z['Jadv'],z['Jtot'],z['Jex'],z['A'],z['Aex'],z['Isens'],z['dS'],z['Sigma'],z['eta_path']])
    plt.plot(bs,vals,label=fr'$q_c={qcv}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel(r'Controller-excess current $J_c^{\rm ex}$ [agents/round]')
plt.title(r'Controller-induced current for $p_{\rm init}=\mathrm{Binomial}(24,0.25)$')
plt.legend()
savefig('fig13_excess_current_vs_b.pdf')
with open(DATA/'thermodynamic_budget_sweep.csv','w',newline='') as f:
    wr=csv.writer(f);wr.writerow(['q_c','b','w_b','gamma_b','p_b','h0','h_b','J_sil','J_adv','J_total','J_c_ex','A_aff','A_aff_excess','I_sens_nats','delta_S_sys_nats','Sigma_nats','eta_path']);wr.writerows(thermo_rows)

# Figure 14: total path transport fraction eta_path. We explicitly avoid calling it control efficiency.
plt.figure(figsize=(7.0,4.6))
for qcv in [6,12,18]:
    vals=[path_thermo(B,int(b),q,qcv,beta,theta,gamma0,p0,gamma1,p1,0.25)['eta_path'] for b in bs]
    plt.plot(bs,vals,label=fr'$q_c={qcv}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel(r'Total path transport fraction $\eta_{\rm path}$')
plt.title('Exact branch-affinity path accounting (not controller-only)')
plt.ylim(0,1.02);plt.legend()
savefig('fig14_eta_path_vs_b.pdf')

# Figure 15: current vs total irreversibility.
plt.figure(figsize=(7.0,4.8))
for qcv in [6,12,18]:
    sig=[];curr=[]
    for b in range(1,25):
        z=path_thermo(B,b,q,qcv,beta,theta,gamma0,p0,gamma1,p1,0.25)
        sig.append(z['Sigma']);curr.append(z['Jex'])
    plt.plot(sig,curr,marker='o',markersize=2.5,label=fr'$q_c={qcv}$')
plt.xlabel(r'Total finite-time path irreversibility $\Sigma$ [nats]')
plt.ylabel(r'Controller-excess current $J_c^{\rm ex}$ [agents/round]')
plt.title('Excess control response versus total path irreversibility')
plt.legend()
savefig('fig15_current_vs_irreversibility.pdf')

# Figure 16: neutral-baseline sufficient case where eta_path becomes controller-associated.
plt.figure(figsize=(7.0,4.6))
for qcv in [6,12,18]:
    vals=[]
    for b in bs:
        z=path_thermo(B,int(b),q,qcv,beta,theta,gamma0,0.5,gamma1,p1,0.25)
        vals.append(z['eta_path'])
    plt.plot(bs,vals,label=fr'$q_c={qcv}$')
plt.xlabel('Controller messages posted $b$');plt.ylabel(r'$\eta_{\rm th}^{(h_0=0)}$')
plt.title('Special case: neutral baseline affinity $h_0=0$')
plt.ylim(0,1.02);plt.legend()
savefig('fig16_eta_neutral_baseline.pdf')

# Numerical validations and summary file.
z9=path_thermo(B,9,q,q_c,beta,theta,gamma0,p0,gamma1,p1,0.25)
kl=direct_path_kl(z9)
w,gb,pb,K0,Kb,Q0,Q1=round_kernels(N,M,B,9,q,gamma0,p0,gamma1,p1)
chi=np.asarray([chi_formula(x,N,M,gamma0,p0,gb,pb) for x in xs])
grid=np.arange(N+1)/N
kernel_chi=Q1@grid-Q0@grid
max_chi_err=float(np.max(np.abs(kernel_chi-chi)))
with open(DATA/'sanity_checks.txt','w') as f:
    f.write(f'baseline N={N}, M={M}, B={B}, q={q}, q_c={q_c}, beta={beta}, theta={theta}, gamma0={gamma0}, p0={p0}, gamma1={gamma1}, p1={p1}\n')
    f.write(f'b=9 w_b={w:.12f} gamma_b={gb:.12f} p_b={pb:.12f}\n')
    f.write(f'max |closed-form chi - matrix mean response| = {max_chi_err:.3e}\n')
    f.write(f'path decomposition Sigma = {z9["Sigma"]:.12f}\n')
    f.write(f'direct path KL = {kl:.12f}\n')
    f.write(f'identity residual = {z9["Sigma"]-kl:.3e}\n')
    f.write(f'J_c_ex={z9["Jex"]:.9f}, A_aff={z9["A"]:.9f}, A_aff_excess={z9["Aex"]:.9f}, I_sens={z9["Isens"]:.9f}, eta_path={z9["eta_path"]:.9f}\n')

print((DATA/'sanity_checks.txt').read_text())
