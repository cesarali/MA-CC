#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python make_figures.py
pdflatex -interaction=nonstopmode -halt-on-error 22082026_feedback_control_single_affinity_report.tex
pdflatex -interaction=nonstopmode -halt-on-error 22082026_feedback_control_single_affinity_report.tex
rm -f 22082026_feedback_control_single_affinity_report.aux \
      22082026_feedback_control_single_affinity_report.log \
      22082026_feedback_control_single_affinity_report.out
