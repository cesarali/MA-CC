import csv
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
DATA = ROOT / "data"
FIG.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

N = 24
GAMMA = 1.0
BASE = dict(h=2.0, q_c=12, beta=4.0, theta=0.5)


def sigm(z):
    return 1.0 / (1.0 + np.exp(-z))


def hypergeom_prob(N, n, q_c, y):
    lo = max(0, q_c - (N - n))
    hi = min(q_c, n)
    if y < lo or y > hi:
        return 0.0
    return math.comb(n, y) * math.comb(N - n, q_c - y) / math.comb(N, q_c)


def sensor_kernel(N, q_c):
    S = np.zeros((N + 1, q_c + 1), dtype=float)
    for n in range(N + 1):
        for y in range(q_c + 1):
            S[n, y] = hypergeom_prob(N, n, q_c, y)
    return S


def policy_vector(q_c, beta, theta):
    y = np.arange(q_c + 1, dtype=float)
    return sigm(beta * (theta - y / q_c))


def action_prob_vector(N, q_c, beta, theta):
    S = sensor_kernel(N, q_c)
    pi1 = policy_vector(q_c, beta, theta)
    return S @ pi1, S, pi1


def controlled_kernel(N, h, gamma=1.0):
    p_h = float(sigm(h))
    K = np.zeros((N + 1, N + 1), dtype=float)
    for n in range(N + 1):
        if n < N:
            K[n, n + 1] = gamma * (N - n) / N * p_h
        if n > 0:
            K[n, n - 1] = gamma * n / N * (1.0 - p_h)
        K[n, n] = 1.0 - K[n].sum()
    return K


def local_information_grid(N=24, h=2.0, q_c=12, beta=4.0, theta=0.5, gamma=1.0):
    a, _, _ = action_prob_vector(N, q_c, beta, theta)
    K = controlled_kernel(N, h, gamma)
    Q0 = np.eye(N + 1)
    grid = np.zeros((N + 1, N), dtype=float)
    Q1 = np.eye(N + 1)

    for b in range(1, N + 1):
        Q1 = Q1 @ K
        for n in range(N + 1):
            an = a[n]
            qmix = (1.0 - an) * Q0[n] + an * Q1[n]
            value = 0.0
            if 1.0 - an > 0.0 and qmix[n] > 0.0:
                value += (1.0 - an) * math.log(Q0[n, n] / qmix[n], 2)
            for m in np.nonzero(Q1[n] > 0.0)[0]:
                if an > 0.0 and qmix[m] > 0.0:
                    value += an * Q1[n, m] * math.log(Q1[n, m] / qmix[m], 2)
            grid[n, b - 1] = value
    return grid, a


def system_entropy(p):
    total = 0.0
    for n, pn in enumerate(p):
        if pn > 0.0:
            total += -pn * math.log(pn) + pn * math.log(math.comb(N, n))
    return total


def binomial_ensemble(N, x0):
    p = np.array([
        math.comb(N, n) * (x0 ** n) * ((1.0 - x0) ** (N - n))
        for n in range(N + 1)
    ], dtype=float)
    return p / p.sum()


def one_cycle_thermodynamics(p_k, *, h, gamma, b, q_c, beta, theta, check_kl=True):
    a, S, pi1 = action_prob_vector(N, q_c, beta, theta)
    K = controlled_kernel(N, h, gamma)
    Q0 = np.eye(N + 1)
    Q1 = np.linalg.matrix_power(K, int(b))

    p_next = np.zeros(N + 1, dtype=float)
    for n in range(N + 1):
        p_next += p_k[n] * ((1.0 - a[n]) * Q0[n] + a[n] * Q1[n])

    pY = p_k @ S
    I_sens = 0.0
    for n in range(N + 1):
        for y in range(q_c + 1):
            if p_k[n] > 0.0 and S[n, y] > 0.0 and pY[y] > 0.0:
                I_sens += p_k[n] * S[n, y] * math.log(S[n, y] / pY[y])

    Lambda = 1.0 - (1.0 - gamma / N) ** b
    J_c = N * Lambda * np.sum(
        p_k * a * (float(sigm(h)) - np.arange(N + 1, dtype=float) / N)
    )
    delta_S = system_entropy(p_next) - system_entropy(p_k)
    Sigma_identity = delta_S + h * J_c + I_sens

    Sigma_kl = float("nan")
    if check_kl:
        Sigma_kl = 0.0
        for n in range(N + 1):
            if p_k[n] <= 0.0:
                continue
            for y in range(q_c + 1):
                if S[n, y] <= 0.0:
                    continue
                for u in (0, 1):
                    pu = (1.0 - pi1[y]) if u == 0 else pi1[y]
                    Qu = Q0 if u == 0 else Q1
                    if pu <= 0.0:
                        continue
                    for m in np.nonzero(Qu[n] > 0.0)[0]:
                        pf = p_k[n] * S[n, y] * pu * Qu[n, m]
                        pr = p_next[m] * pY[y] * pu * Qu[m, n]
                        if pf > 0.0 and pr > 0.0:
                            Sigma_kl += pf * math.log(pf / pr)
        if not np.isclose(Sigma_identity, Sigma_kl, atol=2e-10, rtol=2e-10):
            raise RuntimeError(
                f"KL identity failed: decomposition={Sigma_identity}, direct={Sigma_kl}"
            )

    return dict(
        a=a,
        S=S,
        pi1=pi1,
        K=K,
        Q1=Q1,
        p_next=p_next,
        pY=pY,
        J_c=J_c,
        I_sens=I_sens,
        delta_S_sys=delta_S,
        Sigma=Sigma_identity,
        Sigma_KL=Sigma_kl,
        Lambda=Lambda,
    )


def susceptibility_plot():
    x = np.linspace(0.0, 1.0, 401)
    h = BASE["h"]
    p_h = float(sigm(h))
    b = 12
    gammas = [0.25, 0.5, 0.75, 1.0]
    fig, ax = plt.subplots(figsize=(6.6, 4.2), constrained_layout=True)
    rows = []
    for gamma in gammas:
        Lambda = 1.0 - (1.0 - gamma / N) ** b
        chi = (p_h - x) * Lambda
        ax.plot(x, chi, label=rf"$\gamma={gamma}$")
        for xx, cc in zip(x, chi):
            rows.append((xx, gamma, h, b, Lambda, cc))
    ax.axhline(0.0, linewidth=1)
    ax.axvline(p_h, linestyle="--", linewidth=1, label=rf"$x^*=\sigma(h)={p_h:.2f}$")
    ax.set_xlabel("Target fraction $x$")
    ax.set_ylabel(r"$\chi_{h,\gamma}(x)$")
    ax.set_title(r"Exact susceptibility for $h=2$ and $b=12$")
    ax.legend(fontsize=8)
    fig.savefig(FIG / "susceptibility_vs_compliance.pdf")
    plt.close(fig)

    with open(DATA / "susceptibility.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["x", "gamma", "h", "b", "Lambda_b_gamma", "chi"])
        w.writerows(rows)


def plot_heatmap(grid, title, outpath, vmax=None):
    fig, ax = plt.subplots(figsize=(6.8, 4.5), constrained_layout=True)
    im = ax.imshow(
        grid,
        origin="lower",
        aspect="auto",
        extent=[1, N, 0, 1],
        cmap="viridis",
        vmin=0,
        vmax=vmax,
    )
    ax.set_xlabel("Actuation budget $b$")
    ax.set_ylabel("Target fraction $x=n/N$")
    ax.set_title(title, fontsize=11)
    cb = fig.colorbar(im, ax=ax)
    cb.set_label(r"$T_\pi(n)$ [bits]")
    fig.savefig(outpath, dpi=220)
    plt.close(fig)


def plot_panel(param_name, values, formatter, outpath):
    fig, axes = plt.subplots(2, 2, figsize=(9.4, 7.2), constrained_layout=True)
    grids = []
    for value in values:
        pars = dict(BASE)
        pars[param_name] = value
        grid, _ = local_information_grid(N=N, gamma=GAMMA, **pars)
        grids.append(grid)
    vmax = max(grid.max() for grid in grids)
    for ax, grid, value in zip(axes.flat, grids, values):
        im = ax.imshow(
            grid,
            origin="lower",
            aspect="auto",
            extent=[1, N, 0, 1],
            cmap="viridis",
            vmin=0,
            vmax=vmax,
        )
        ax.set_title(formatter(value), fontsize=10)
        ax.set_xlabel("$b$")
        ax.set_ylabel("$x=n/N$")
    cb = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.96)
    cb.set_label(r"$T_\pi(n)$ [bits]")
    display = {"h": "$h$", "q_c": "$q_c$", "beta": "$\\beta$", "theta": "$\\theta$"}[param_name]
    fig.suptitle(f"State-local action-to-population information: varying {display}", fontsize=12)
    fig.savefig(outpath, dpi=220)
    plt.close(fig)


def local_information_figures():
    grid, _ = local_information_grid(N=N, gamma=GAMMA, **BASE)
    plot_heatmap(
        grid,
        r"Exact state-local action-to-population information $(h=2,\ q_c=12,\ \beta=4,\ \theta=1/2)$",
        FIG / "fig_local_information_baseline.png",
    )
    with open(DATA / "baseline_local_information.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "x", "b", "T_pi_bits"])
        for n in range(N + 1):
            for b in range(1, N + 1):
                w.writerow([n, n / N, b, grid[n, b - 1]])

    plot_panel("h", [0.5, 1.0, 2.0, 4.0], lambda v: rf"$h={v}$", FIG / "fig_local_information_vary_h.png")
    plot_panel("q_c", [4, 8, 12, 20], lambda v: rf"$q_c={v}$", FIG / "fig_local_information_vary_qc.png")
    plot_panel("beta", [1.0, 2.0, 4.0, 8.0], lambda v: rf"$\beta={v}$", FIG / "fig_local_information_vary_beta.png")
    plot_panel("theta", [0.25, 0.4, 0.5, 0.75], lambda v: rf"$\theta={v}$", FIG / "fig_local_information_vary_theta.png")


def average_local_information_summary():
    fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.8), constrained_layout=True)
    configs = [
        ("h", [0.5, 1.0, 2.0, 4.0]),
        ("q_c", [4, 8, 12, 20]),
        ("beta", [1.0, 2.0, 4.0, 8.0]),
        ("theta", [0.25, 0.4, 0.5, 0.75]),
    ]
    rows = []
    for ax, (param_name, values) in zip(axes.flat, configs):
        for value in values:
            pars = dict(BASE)
            pars[param_name] = value
            grid, _ = local_information_grid(N=N, gamma=GAMMA, **pars)
            mean_curve = grid.mean(axis=0)
            ax.plot(np.arange(1, N + 1), mean_curve, label=f"{param_name}={value}")
            for b, mean_t in enumerate(mean_curve, start=1):
                rows.append((param_name, value, b, mean_t))
        ax.set_xlabel("$b$")
        ax.set_ylabel(r"$\overline{T}_\pi=(N+1)^{-1}\sum_n T_\pi(n)$ [bits]")
        ax.set_title(f"Varying {param_name}")
        ax.legend(fontsize=7)
    fig.savefig(FIG / "state_averaged_local_information_summary.pdf")
    plt.close(fig)

    with open(DATA / "state_averaged_local_information.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["parameter", "value", "b", "mean_T_pi_bits"])
        w.writerows(rows)


def current_irreversibility_figure():
    p0 = binomial_ensemble(N, 0.25)
    h = 2.0
    gamma = 0.75
    beta = 4.0
    theta = 0.5
    qcs = [4, 8, 12, 20]
    bs = list(range(1, N + 1))
    rows = []

    fig, ax = plt.subplots(figsize=(6.8, 4.6), constrained_layout=True)
    for q_c in qcs:
        sigmas = []
        currents = []
        for b in bs:
            result = one_cycle_thermodynamics(
                p0,
                h=h,
                gamma=gamma,
                b=b,
                q_c=q_c,
                beta=beta,
                theta=theta,
                check_kl=True,
            )
            sigmas.append(result["Sigma"])
            currents.append(result["J_c"])
            rows.append((
                q_c,
                b,
                h,
                gamma,
                beta,
                theta,
                result["J_c"],
                result["Sigma"],
                result["Sigma_KL"],
                result["delta_S_sys"],
                result["I_sens"],
                result["Lambda"],
            ))
        ax.plot(sigmas, currents, marker="o", markersize=2.8, linewidth=1.2, label=rf"$q_c={q_c}$")
        if q_c == max(qcs):
            for bmark in (1, 6, 12, 18, 24):
                idx = bmark - 1
                ax.annotate(rf"$b={bmark}$", (sigmas[idx], currents[idx]), fontsize=6.5, xytext=(3, 2), textcoords="offset points")

    ax.set_xlabel(r"Finite-time irreversibility $\Sigma$ [nats]")
    ax.set_ylabel(r"Mean controlled current $J_c$")
    ax.set_title(r"Control versus irreversibility for $p_0(n)=\mathrm{Binomial}(24,0.25)$")
    ax.legend(fontsize=8, title="sensor size")
    fig.savefig(FIG / "current_vs_irreversibility.pdf")
    plt.close(fig)

    with open(DATA / "current_vs_irreversibility.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "q_c", "b", "h", "gamma", "beta", "theta", "J_c",
            "Sigma_identity_nats", "Sigma_direct_KL_nats", "delta_S_sys_nats",
            "I_sensing_nats", "Lambda_b_gamma",
        ])
        w.writerows(rows)


if __name__ == "__main__":
    susceptibility_plot()
    local_information_figures()
    average_local_information_summary()
    current_irreversibility_figure()
    print(f"Wrote figures to {FIG}")
    print(f"Wrote data to {DATA}")
