import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

OUT = Path('/mnt/data/21082026_feedback_control_efficiency_local_info_report/figures')
OUT.mkdir(parents=True, exist_ok=True)

N = 24
GAMMA = 1.0
BASE = dict(h_c=2.0, q_c=12, beta=4.0, theta=0.5)


def sigm(z):
    return 1.0 / (1.0 + np.exp(-z))


def hypergeom_prob(N, n, qc, y):
    if y < max(0, qc - (N - n)) or y > min(qc, n):
        return 0.0
    return math.comb(n, y) * math.comb(N - n, qc - y) / math.comb(N, qc)


def action_prob_vector(N, q_c, beta, theta):
    a = np.zeros(N + 1)
    for n in range(N + 1):
        lo = max(0, q_c - (N - n))
        hi = min(q_c, n)
        val = 0.0
        for y in range(lo, hi + 1):
            val += hypergeom_prob(N, n, q_c, y) * sigm(beta * (theta - y / q_c))
        a[n] = val
    return a


def controlled_kernel(N, h_c, gamma=1.0):
    p = sigm(h_c)
    K = np.zeros((N + 1, N + 1))
    for n in range(N + 1):
        if n < N:
            K[n, n + 1] = gamma * (N - n) / N * p
        if n > 0:
            K[n, n - 1] = gamma * n / N * (1.0 - p)
        K[n, n] = 1.0 - K[n].sum()
    return K


def local_information_grid(N=24, h_c=2.0, q_c=12, beta=4.0, theta=0.5, gamma=1.0):
    a = action_prob_vector(N, q_c, beta, theta)
    K = controlled_kernel(N, h_c, gamma)
    I = np.eye(N + 1)
    grid = np.zeros((N + 1, N))
    current = np.eye(N + 1)
    for b in range(1, N + 1):
        current = current @ K  # K^b
        for n in range(N + 1):
            an = a[n]
            mix = (1.0 - an) * I[n] + an * current[n]
            val = 0.0
            # u=0 branch
            val += (1.0 - an) * math.log(1.0 / mix[n], 2)
            # u=1 branch
            nz = np.nonzero(current[n] > 0)[0]
            for m in nz:
                p1 = current[n, m]
                val += an * p1 * math.log(p1 / mix[m], 2)
            grid[n, b - 1] = val
    return grid, a


def plot_heatmap(grid, title, outpath, vmax=None):
    fig, ax = plt.subplots(figsize=(6.8, 4.5), constrained_layout=True)
    extent = [1, N, 0, 1]
    im = ax.imshow(grid / 1.0, origin='lower', aspect='auto', extent=extent, cmap='viridis', vmin=0, vmax=vmax)
    ax.set_xlabel('Actuation budget $b$')
    ax.set_ylabel('Target fraction $x = n/N$')
    ax.set_title(title, fontsize=11)
    cb = fig.colorbar(im, ax=ax)
    cb.set_label('$T_\\pi(n)$ [bits]')
    fig.savefig(outpath, dpi=220)
    plt.close(fig)


def plot_panel(param_name, values, formatter, outpath):
    fig, axes = plt.subplots(2, 2, figsize=(9.4, 7.2), constrained_layout=True)
    vmax = None
    grids = []
    params_list = []
    for val in values:
        pars = dict(BASE)
        pars[param_name] = val
        grid, a = local_information_grid(N=N, gamma=GAMMA, **pars)
        grids.append(grid)
        params_list.append((pars, a))
    vmax = max(g.max() for g in grids)
    for ax, grid, (pars, a), val in zip(axes.flat, grids, params_list, values):
        im = ax.imshow(grid, origin='lower', aspect='auto', extent=[1, N, 0, 1], cmap='viridis', vmin=0, vmax=vmax)
        ax.set_title(formatter(val), fontsize=10)
        ax.set_xlabel('$b$')
        ax.set_ylabel('$x=n/N$')
    cb = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.96)
    cb.set_label('$T_\\pi(n)$ [bits]')
    fig.suptitle(f'State-local action-to-population information: varying {param_name}', fontsize=12)
    fig.savefig(outpath, dpi=220)
    plt.close(fig)


def susceptibility_plot():
    x = np.linspace(0, 1, 401)
    hc = BASE['h_c']
    p = sigm(hc)
    b = 12
    gammas = [0.25, 0.5, 0.75, 1.0]
    fig, ax = plt.subplots(figsize=(6.6, 4.2), constrained_layout=True)
    for g in gammas:
        Lam = 1.0 - (1.0 - g / N) ** b
        xi = (p - x) * Lam
        ax.plot(x, xi, label=rf'$\gamma={g}$')
    ax.axhline(0, linewidth=1)
    ax.axvline(p, linestyle='--', linewidth=1, label=rf'$x^*=\sigma(h_c)={p:.2f}$')
    ax.set_xlabel('Target fraction $x$')
    ax.set_ylabel(r'$\chi_{h_c,\gamma}(x)$')
    ax.set_title(r'Exact susceptibility for $h_c=2$ and $b=12$')
    ax.legend(fontsize=8)
    fig.savefig(OUT / 'susceptibility_vs_compliance.pdf')
    plt.close(fig)


def system_entropy(p):
    val = 0.0
    for n, pn in enumerate(p):
        if pn > 0:
            val += -pn * math.log(pn) + pn * math.log(math.comb(N, n))
    return val


def efficiency_curve():
    qc = BASE['q_c']; beta = BASE['beta']; theta = BASE['theta']; gamma = 0.75
    b = 12; h_e = 0.6
    x0 = 0.25
    p_state = np.array([math.comb(N, n) * x0**n * (1-x0)**(N-n) for n in range(N+1)], dtype=float)
    p_state /= p_state.sum()
    # sensing information (depends only on p_state and sensor)
    pY = np.zeros(qc + 1)
    S = np.zeros((N+1, qc+1))
    for n in range(N+1):
        for y in range(qc+1):
            S[n,y] = hypergeom_prob(N, n, qc, y)
        pY += p_state[n]*S[n]
    Isens = 0.0
    for n in range(N+1):
        for y in range(qc+1):
            if S[n,y] > 0 and pY[y] > 0:
                Isens += p_state[n]*S[n,y]*math.log(S[n,y]/pY[y])

    hcs = np.linspace(0.2, 4.0, 100)
    etas = []
    for h_c in hcs:
        a = action_prob_vector(N, qc, beta, theta)
        F = h_c - h_e
        pF = sigm(F)
        Lam = 1.0 - (1.0 - gamma/N)**b
        Jc = N * Lam * np.sum(p_state * a * (pF - np.arange(N+1)/N))
        K = controlled_kernel(N, F, gamma)
        Q1 = np.linalg.matrix_power(K, b)
        pprime = np.zeros(N+1)
        for n in range(N+1):
            pprime[n] += p_state[n]*(1-a[n])
            pprime += p_state[n]*a[n]*Q1[n]
        denom = h_c*Jc + Isens + (system_entropy(pprime) - system_entropy(p_state))
        eta = (h_e*Jc/denom) if denom > 0 and Jc > 0 else np.nan
        etas.append(eta)
    fig, ax = plt.subplots(figsize=(6.6, 4.2), constrained_layout=True)
    ax.plot(hcs, etas)
    ax.axhline(1.0, linestyle='--', linewidth=1)
    ax.set_ylim(0, min(1.05, np.nanmax(etas) + 0.05))
    ax.set_xlabel(r'Controller affinity $h_c$')
    ax.set_ylabel(r'$\eta_{\rm th}$')
    ax.set_title(r'Illustrative exact efficiency for $b=12$, $q_c=12$, $\beta=4$, $\theta=1/2$, $h_e=0.6$, $\gamma=0.75$')
    fig.savefig(OUT / 'thermodynamic_efficiency_vs_affinity.pdf')
    plt.close(fig)


def average_local_information_summary():
    fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.8), constrained_layout=True)
    configs = [
        ('h_c', [0.5, 1.0, 2.0, 4.0]),
        ('q_c', [4, 8, 12, 20]),
        ('beta', [1.0, 2.0, 4.0, 8.0]),
        ('theta', [0.25, 0.4, 0.5, 0.75]),
    ]
    for ax, (param_name, values) in zip(axes.flat, configs):
        for val in values:
            pars = dict(BASE)
            pars[param_name] = val
            grid, _ = local_information_grid(N=N, gamma=GAMMA, **pars)
            mean_curve = grid.mean(axis=0)
            ax.plot(np.arange(1, N+1), mean_curve, label=f'{param_name}={val}')
        ax.set_xlabel('$b$')
        ax.set_ylabel(r'$\overline{T}_\pi = \frac{1}{N+1}\sum_n T_\pi(n)$ [bits]')
        ax.set_title(f'Varying {param_name}')
        ax.legend(fontsize=7)
    fig.savefig(OUT / 'state_averaged_local_information_summary.pdf')
    plt.close(fig)


if __name__ == '__main__':
    grid, _ = local_information_grid(N=N, gamma=GAMMA, **BASE)
    plot_heatmap(grid, r'Exact state-local action-to-population information $(h_c=2,\ q_c=12,\ \beta=4,\ \theta=1/2)$', OUT / 'fig_local_information_baseline.png')
    plot_panel('h_c', [0.5, 1.0, 2.0, 4.0], lambda v: rf'$h_c={v}$', OUT / 'fig_local_information_vary_hc.png')
    plot_panel('q_c', [4, 8, 12, 20], lambda v: rf'$q_c={v}$', OUT / 'fig_local_information_vary_qc.png')
    plot_panel('beta', [1.0, 2.0, 4.0, 8.0], lambda v: rf'$\beta={v}$', OUT / 'fig_local_information_vary_beta.png')
    plot_panel('theta', [0.25, 0.4, 0.5, 0.75], lambda v: rf'$\theta={v}$', OUT / 'fig_local_information_vary_theta.png')
    average_local_information_summary()
    susceptibility_plot()
    efficiency_curve()
