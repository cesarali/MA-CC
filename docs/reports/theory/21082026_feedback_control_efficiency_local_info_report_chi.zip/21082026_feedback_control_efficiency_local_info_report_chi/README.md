# 21082026 Feedback control efficiency local-info report

Contents:
- `21082026_feedback_control_efficiency_local_info_report.pdf`: updated report.
- `21082026_feedback_control_efficiency_local_info_report.tex`: LaTeX source.
- `make_figures.py`: script used to generate the figures exactly.
- `figures/`: all generated figures used in the report.

Main addition relative to the previous clean derivation:
- a new section on exact state-local action-to-population information
  `T_pi(n) = I(U; m | n)`.
- a baseline heatmap and parameter sweeps over `h_c`, `q_c`, `beta`, and `theta`.
