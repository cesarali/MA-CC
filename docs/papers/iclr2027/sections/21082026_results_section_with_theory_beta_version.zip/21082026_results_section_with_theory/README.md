# Results section with theory plots

This revision deliberately includes the theory figures from the latest finite-time feedback-control report together with the empirical results.

Main figures:
- empirical state-matched susceptibility + exact compliance theory
- empirical signed response + empirical local information + exact theory landscape + support
- full beta theory sweep + state-averaged theory summary
- empirical information-response efficiency
- empirical thermodynamic-efficiency proxy + exact thermodynamic efficiency theory + sensing information

The paper-facing text never refers to internal study numbers.
